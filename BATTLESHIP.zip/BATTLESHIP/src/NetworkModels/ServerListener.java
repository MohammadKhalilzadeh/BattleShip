package NetworkModels;

import java.io.IOException;
import java.io.ObjectInputStream;

public class ServerListener implements Runnable
{
	ObjectInputStream ois;
	
	

	public ServerListener(ObjectInputStream ois) 
	{
		this.ois = ois;
	}



	@Override
	public void run() 
	{
		Message msg;
		try
		{
			msg = (Message)ois.readObject();
			System.out.println("Server : "+msg.text);
		}
		catch (ClassNotFoundException e) 
		{
			System.out.println(e);
		} 
		catch (IOException e) 
		{
			System.out.println(e);
		}
		
	}
	

}
