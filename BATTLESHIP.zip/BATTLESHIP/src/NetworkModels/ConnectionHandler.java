package NetworkModels;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.List;

public class ConnectionHandler implements Runnable 
{

	private ServerSocket listenerSocket;
	private List<Socket> socketList;
	private List<ClientHandler> clientHandlerList;
	private List<Thread> clientThreadList;
	
	public ConnectionHandler(ServerSocket serverSocket,List<Socket> socketList , List<ClientHandler> clientHandlerList,List<Thread> clientThreadList)
	{
		this.listenerSocket = listenerSocket;
		this.socketList = socketList;
		this.clientHandlerList = clientHandlerList;
		this.clientThreadList = clientThreadList;
	}
	
	@Override
	public void run() 
	{	
		while (true) 
		{
			try 
			{
			
				Socket newClient = listenerSocket.accept();
				synchronized (socketList) 
				{
					socketList.add(newClient);
				}
				
				ClientHandler newclientHandler = new ClientHandler(newClient);
				synchronized (clientHandlerList) 
				{
					clientHandlerList.add(newclientHandler);
				}
				
				Thread newClientThread = new Thread(newclientHandler);
				synchronized (clientThreadList) 
				{
					clientHandlerList.add(newclientHandler);
				}
				newClientThread.start();
				System.out.println("New Client Accepted");
			}
			catch(IOException e)
			{
				System.out.println(e);
			}
		}
	}

}
