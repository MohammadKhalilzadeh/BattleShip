package NetworkModels;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client 
{
	private Socket socket = null;
	private ObjectOutputStream objectOutputStream = null;
	private ObjectInputStream objectInputStream = null ;
	public void Client()
	{
		try
		{
			socket = new Socket("127.0.0.1",5000);
			objectOutputStream = new ObjectOutputStream(socket.getOutputStream());
			objectInputStream = new ObjectInputStream(socket.getInputStream());
			
			ServerListener serverListener = new ServerListener(objectInputStream);
			Thread thread = new Thread(serverListener);
			thread.start();
			System.out.println("Receiver Thread Created");
			Scanner scanner = new Scanner(System.in);
			String line = "";
			
			while( !(line=scanner.nextLine()).equals("exit") )
			{
				Message message = new Message();
				message.senderUserName = "Mohammad";
				message.senderIPAddress = socket.getInetAddress().toString();
				message.uuid = 1000;
				
				message.text = line;
				message.uuid++;
				objectOutputStream.writeObject(message);
				System.out.println("Sent");
			}
			thread.stop();
			thread.suspend();
			objectOutputStream.close();
			socket.close();
			System.out.println("All Done!");
			
		}
		catch(UnknownHostException e1)
		{
			System.out.println(e1);
		}
		catch(IOException e2)
		{
			System.out.println(e2);
		}
	}
}
