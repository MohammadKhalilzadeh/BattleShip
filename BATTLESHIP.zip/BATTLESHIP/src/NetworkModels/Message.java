package NetworkModels;

import java.io.IOException;
import java.io.Serializable;

public class Message implements Serializable 
{
	private static final long serialVersionUID = 2L;
	int uuid;
	String senderIPAddress;
	String senderUserName;
	String receiverIPAddress;
	String receiverUserName;
	String dateTime;
	String text;
	
	public final void writeObject(Object object) throws IOException
	{
		
	}
	
	public final Object readObject() throws IOException,ClassNotFoundException
	{
		return null;
	}
}
