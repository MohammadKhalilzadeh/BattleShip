package NetworkModels;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.LinkedList;
import java.util.Queue;

public class ClientHandler implements Runnable
{

	private ObjectOutputStream oos;
	private ObjectInputStream ois;
	private Queue<Message> inQueue;
	
	public ClientHandler(Socket socket) throws IOException 
	{
		oos = new ObjectOutputStream(socket.getOutputStream());
		ois = new ObjectInputStream(socket.getInputStream());
		inQueue = new LinkedList<Message>();
	}
	
	public boolean SendToClient(Message message) throws IOException
	{
		oos.writeObject(message);
		return true;
	}
	
	public Message ReceiceFromClient()
	{
		Message message = null;
		if (inQueue.isEmpty()) 
		{
			return null;
		}
		else
		{
			message = inQueue.remove();
		}
		System.out.println("In Receive : "+message.text);
		return message;
		
	}
	
	@Override
	public void run() 
	{
		while(true)
		{
			try
			{
				Message message = (Message)ois.readObject();
				inQueue.add(message);
				System.out.println("Debug in Thread : "+message.text);
			}
			catch(IOException e)
			{
				System.out.println(e);
			}
			catch(ClassNotFoundException e)
			{
				System.out.println(e);
			}
		}
	}

}
