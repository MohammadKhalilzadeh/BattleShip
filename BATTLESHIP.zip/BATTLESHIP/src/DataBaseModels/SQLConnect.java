package DataBaseModels;

import java.sql.Connection;
import java.sql.DriverManager;

public class SQLConnect 
{
	public static final String HOST_URL = "jdbc:mysql://localhost:3306/battleship";
	public static final String USER = "root";
	public static final String PASSWORD = "";
	
	public static Connection Connect()
	{
		try
		{
			return DriverManager.getConnection(HOST_URL, USER, PASSWORD);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return null;
	}
}
