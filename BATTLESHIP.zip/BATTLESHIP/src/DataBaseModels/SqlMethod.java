package DataBaseModels;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class SqlMethod 
{
	public void MakeMatch(String player1,String player2,int ShipNo,int mapRow,int mapCol)
	{
		String query = "insert into current_game values ( '"+player1+"','"+player2+"',+'"+ShipNo+"','"+mapRow+"','"+mapCol+"' )";
		
		try
		{
			System.out.println("* * * Making The Current Game * * *");
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println(" * * Driver Loaded * * ");
			Connection connection = DriverManager.getConnection(SQLConnect.HOST_URL, SQLConnect.USER, SQLConnect.PASSWORD);
			System.out.println(" * * Connection Made * * ");
			Statement statement = connection.createStatement();
			System.out.println(" * * Statement Created * * ");
			ResultSet resultSet = statement.executeQuery("select * from current_game");
			System.out.println(" * * Query Executed * * ");
			statement.executeUpdate(query);
			connection.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	
	public static int MapRows()
	{
		int rows = 0;
		try {
		String query = "SELECT * FROM current_game";
		System.out.println("* * * Making The Current Game * * *");
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println(" * * Driver Loaded * * ");
		Connection connection = DriverManager.getConnection(SQLConnect.HOST_URL, SQLConnect.USER, SQLConnect.PASSWORD);
		System.out.println(" * * Connection Made * * ");
		Statement statement = connection.createStatement();
		System.out.println(" * * Statement Created * * ");
//		ResultSet resultSet = statement.executeQuery(query);
		System.out.println("Done1");
		ResultSet resultSet = statement.executeQuery(query);
		resultSet.next();
//		String r = resultSet.getString(4);
//		rows = Integer.parseInt(r);
//		System.out.println("Done1");
		rows = resultSet.getInt(4);
		System.out.println("Done2");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		return rows;
	}
	
	public static int MapColumns()
	{
		int columns = 0;
		try {
		String query = "SELECT * FROM current_game";
		System.out.println("* * * Making The Current Game * * *");
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println(" * * Driver Loaded * * ");
		Connection connection = DriverManager.getConnection(SQLConnect.HOST_URL, SQLConnect.USER, SQLConnect.PASSWORD);
		System.out.println(" * * Connection Made * * ");
		Statement statement = connection.createStatement();
		System.out.println(" * * Statement Created * * ");
		ResultSet resultSet = statement.executeQuery(query);
		resultSet.next();
		System.out.println("Done1");
		String r = resultSet.getString(5);
		System.out.println("Done2");
		columns = Integer.parseInt(r);
		System.out.println("Done3");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		return columns;
	}
	
	public static int ShipsNumber()
	{
		int ships = 0;
		try {
		String query = "SELECT * FROM current_game";
		System.out.println("* * * Making The Current Game * * *");
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println(" * * Driver Loaded * * ");
		Connection connection = DriverManager.getConnection(SQLConnect.HOST_URL, SQLConnect.USER, SQLConnect.PASSWORD);
		System.out.println(" * * Connection Made * * ");
		Statement statement = connection.createStatement();
		System.out.println(" * * Statement Created * * ");
		ResultSet resultSet = statement.executeQuery(query);
		resultSet.next();
		System.out.println("Done1");
		String r = resultSet.getString(3);
		System.out.println("Done2");
		ships = Integer.parseInt(r);
		System.out.println("Done3");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		return ships;
	}
}
