package models;

public class Cell 
{
	private boolean isBusy;
	private int row;
	private int column;
	private boolean isUsable;
	
	
	Cell(int row, int column) 
	{
		this.row = row;
		this.column = column;
		this.isBusy = false;
		this.isUsable = true;
	}
	
	public boolean isBusy() 
	{
		return isBusy;
	}
	public void setBusy(boolean isBusy) 
	{
		this.isBusy = isBusy;
	}
	
	public int getRow() 
	{
		return row;
	}
	public void setRow(int row) 
	{
		this.row = row;
	}
	
	public int getColumn() 
	{
		return column;
	}
	public void setColumn(int column) {
		this.column = column;
	}
	
	public boolean isUsable() 
	{
		return isUsable;
	}
	public void setUsable(boolean isUsable) 
	{
		this.isUsable = isUsable;
	}
	
}
