package models;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import javafx.scene.image.Image;

public class ShipPiece 
{
	private Image shipImage;
	private boolean isDead;
	private boolean player1;
	
	
//----Getter and Setters-----
	
	public Image getShipImage() 
	{
		return shipImage;
	}
	public void setShipImage(String file) 
	{
		try 
		{
			shipImage = new Image(new FileInputStream(file));
		}
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		}
	}
	
	public boolean isDead() 
	{
		return isDead;
	}
	public void setDead(boolean isDead) 
	{
		this.isDead = isDead;
	}
	
	public boolean isPlayer1() 
	{
		return player1;
	}
	public void setPlayer1(boolean player1) {
		this.player1 = player1;
	}
	
	public void Damage()
	{
		isDead = true;
		if (player1) 
		{
			setShipImage("");
		}
		else
		{
			setShipImage("");
		}
	}
	
	public boolean IsDamaged()
	{
		return isDead;
	}
}
