package models;

public class Player 
{
	private String name;
	private int winNum;
	private int rank;
	private float winPercent;
	
	public Player(String name)
	{
		this.name = name;
		winNum = 0;
		winPercent = 0;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getWinNum() {
		return winNum;
	}
	public void setWinNum(int winNum) {
		this.winNum = winNum;
	}
	public int getRank() {
		return rank;
	}
	public void setRank(int rank) {
		this.rank = rank;
	}
	public float getWinPercent() {
		return winPercent;
	}
	public void setWinPercent(float winPercent) {
		this.winPercent = winPercent;
	}
	
	
}
