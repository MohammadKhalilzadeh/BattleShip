package models;

import java.awt.Point;
import java.util.ArrayList;

public class Ship 
{
	private ShipPiece[] pieces;
	private Point startPosition;
	
	Ship(ShipPiece[] pieces)
	{
		this.pieces = pieces;
		startPosition=new Point(0,0);
	}
	
	public Ship(ArrayList<ShipPiece> list) 
	{
		pieces = list.toArray(new ShipPiece[0]);
		startPosition = new Point(0, 0);
	}
	
	public boolean IsGone() 
	{
		boolean isDead = true;
		
		for (int i = 0; i < pieces.length; i++) 
		{
			if (!pieces[i].IsDamaged()) 
			{
				isDead = false;
			}
		}
		
		return isDead;
	}
	
	public ShipPiece[] getPieces() {
		return pieces;
	}
	public void setPieces(ShipPiece[] pieces) {
		this.pieces = pieces;
	}
	public Point getStartPosition() {
		return startPosition;
	}
	public void setStartPosition(Point startPosition) {
		this.startPosition = startPosition;
	}
	
}
