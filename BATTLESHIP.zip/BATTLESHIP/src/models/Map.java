package models;

public class Map 
{
	private Cell[][] cells;
	private int rowNum;
	private int colNum;
	
	public Cell getCell(int row,int column)
	{
		if (!isInMap(row, column)) 
		{
			return null;
		}
		return cells[row][column];
	}
	
	public boolean isInMap(int row,int column)
	{
		return (row >= 0 && row < rowNum && column >= 0 && column < colNum);
	}
	
	public Cell[][] getCells() {
		return cells;
	}
	public void setCells(Cell[][] cells) {
		this.cells = cells;
	}
	public int getRowNum() {
		return rowNum;
	}
	public void setRowNum(int rowNum) {
		this.rowNum = rowNum;
	}
	public int getColNum() {
		return colNum;
	}
	public void setColNum(int colNum) {
		this.colNum = colNum;
	}

	public Map(int rowNum, int colNum) 
	{
		this.rowNum = rowNum;
		this.colNum = colNum;
	}
		
}
