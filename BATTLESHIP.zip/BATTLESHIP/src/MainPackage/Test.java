package MainPackage;

import DataBaseModels.SqlMethod;

public class Test 
{
	SqlMethod sqlMethod = new SqlMethod();
	
	public static void main(String[] args)
	{
		System.out.println(SqlMethod.MapRows());
		System.out.println(SqlMethod.MapColumns());
	}

}
