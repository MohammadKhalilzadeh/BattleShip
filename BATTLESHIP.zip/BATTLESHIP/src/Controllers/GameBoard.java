package Controllers;

import java.awt.Color;
import java.awt.Insets;
import java.net.URL;
import java.util.ResourceBundle;

import DataBaseModels.SqlMethod;
import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.input.MouseDragEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Region;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.StackPane;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

public class GameBoard implements Initializable
{
	@FXML
	private BorderPane pane;
	@FXML
	private GridPane gridPane = new GridPane();
	@FXML
	private AnchorPane pane2 = new AnchorPane();
//	@FXML
//	private Rectangle rectangle[];

	@FXML
	private Button ship[];
	
	SqlMethod sqlMethod = new SqlMethod();
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) 
	{
		try 
		{
		
		int row = SqlMethod.MapRows();
		int column = SqlMethod.MapColumns();
		int number = SqlMethod.ShipsNumber();
		gridPane.setGridLinesVisible(true);
//		rectangle.setVisible(true);
		pane2.setVisible(true);
		pane2.toFront();

		
		int width = 80 * row;
		int hight = 80 * column;
		
//		rectangle.maxHeight(80);
//		rectangle.maxWidth(80*number);
//		rectangle.setStyle("-fx-background-color: blue;");

		for (int i = 0; i < number; i++) 
		{
//			rectangle[i] = new Rectangle();
//			rectangle[i].setVisible(true);
//			rectangle[i].maxHeight(80);
//			rectangle[i].maxWidth(80*number);
//			rectangle[i].setStyle("-fx-background-color: blue;");
//			rectangle[i].toFront();
//			pane2.getChildren().add(i, rectangle[i]);
		}
		
		for (int i = 1; i < 5; i++) 
		{
			
//			pane.setRight(rectangle);
//			pane2.getChildren().add(i, rectangle);
			
		}
		
		for(int i=0;i<column;i++)
		{
			ColumnConstraints columnConstraints = new ColumnConstraints();
			columnConstraints.setPercentWidth(100.0/column);
			gridPane.getColumnConstraints().add(columnConstraints);
		}
		
		for(int i=0;i<row;i++)
		{
			RowConstraints rowConstraints = new RowConstraints();
			rowConstraints.setPercentHeight(100.0/row);
			gridPane.getRowConstraints().add(rowConstraints);
		}
		
		gridPane.setStyle("-fx-background-color: BLUE;");
		gridPane.setPrefSize(800, 800);
		gridPane.setMaxSize(width, hight);
		pane.setLeft(gridPane);
		pane.setRight(pane2);
		
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
/*
	@Override
	public void start(Stage arg0) throws Exception {
//		pane2.getChildren().add(rectangle);
		
	}
*/	
}
