package Controllers;

import java.net.URL;
import java.util.ResourceBundle;

import DataBaseModels.SqlMethod;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.ColumnConstraintsBuilder;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.StackPane;

public class TestView implements Initializable 
{
	@FXML
	private BorderPane pane = new BorderPane();
	@FXML
	private GridPane gridPane = new GridPane();
	
	SqlMethod SqlMethod = new SqlMethod();

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) 
	{
		int row = DataBaseModels.SqlMethod.MapRows();
		int column = DataBaseModels.SqlMethod.MapColumns();
		int number = DataBaseModels.SqlMethod.ShipsNumber();
		gridPane.setGridLinesVisible(true);
		
		int width = 80 * row;
		int hight = 80 * column;
		
		gridPane.setGridLinesVisible(true);
		gridPane.setStyle("-fx-background-color: blue;");
		gridPane.setMaxSize(width, hight);
		
		for(int i=0 ; i<column ; i++)
		{
			ColumnConstraints columnConstraints = new ColumnConstraints();
			columnConstraints.setPercentWidth(100.0/column);
			gridPane.getColumnConstraints().add(columnConstraints);
		}
		
		for (int i = 0; i < row; i++) 
		{
			RowConstraints rowConstraints = new RowConstraints();
			rowConstraints.setPercentHeight(100.0/row);
			gridPane.getRowConstraints().add(rowConstraints);
		}
		
		pane.setCenter(gridPane);
	}
	
}
