package Controllers;

import java.net.URL;
import java.util.ResourceBundle;

import DataBaseModels.SqlMethod;
import GameLogic.GameLogic;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class OfflineController implements Initializable
{
	@FXML
	private TextField name1,name2,rows,columns;
	@FXML
	private Button start;
	@FXML
	private ComboBox<String> ships;
	
	private Stage primaryStage = new Stage();
	private SqlMethod sqlMethod = new SqlMethod();
	private GameLogic gameLogic = new GameLogic();
	
	ObservableList<String> shipNum = FXCollections.observableArrayList("1","2","3","4");
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) 
	{	
		ships.setItems(shipNum);
	}
	
	
	public void MakeGame(ActionEvent event)
	{
		try 
		{
		String name_1 = name1.getText();
		String name_2 = name2.getText();
		int row = Integer.parseInt(rows.getText());
		int col = Integer.parseInt(columns.getText());
		int ship = Integer.parseInt(ships.getValue());
		System.out.println("done 1");
		sqlMethod.MakeMatch(name_1, name_2, ship, row, col);
		System.out.println("done 2");
		gameLogic.CreatePlayer1(name_1);
		gameLogic.CreatePlayer2(name_2);
		gameLogic.CreateMap(row, col);
		
		Parent root = FXMLLoader.load(getClass().getResource("/Screens/GameBoard.fxml"));
//		Parent root = FXMLLoader.load(getClass().getResource("/Screens/TestView.fxml"));
		Scene scene = new Scene(root,1200,900);
		primaryStage.setScene(scene);
		primaryStage.show();
		
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		
	}
	
}
