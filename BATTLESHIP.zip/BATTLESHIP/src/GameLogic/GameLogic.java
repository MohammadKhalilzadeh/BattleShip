package GameLogic;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import models.Map;
import models.Player;

public class GameLogic 
{
	private Player player;
	private Map map;
	
	private ObservableList<Player> Players = FXCollections.observableArrayList();
	private ObservableList<Player> Player1s = FXCollections.observableArrayList();
	private ObservableList<Player> Player2s = FXCollections.observableArrayList();
	private ObservableList<Map> maps = FXCollections.observableArrayList();
	
	public void CreatePlayer1(String name1)
	{
		player = new Player(name1);
		Player1s.add(player);
		Players.add(player);
	}
	
	public void CreatePlayer2(String name2)
	{
		player = new Player(name2);
		Player2s.add(player);
		Players.add(player);
		
	}
	
	public void CreateMap(int row,int column)
	{
		map = new Map(row, column);
		maps.add(map);
	}

//-----Getters and Setters-----	
	public Player getPlayer() {
		return player;
	}

	public void setPlayer(Player player) {
		this.player = player;
	}

	public Map getMap() {
		return map;
	}

	public void setMap(Map map) {
		this.map = map;
	}
}
